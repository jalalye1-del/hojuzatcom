class BeautyService {
  const BeautyService({
    required this.id,
    required this.name,
    required this.category,
    required this.durationMinutes,
    required this.price,
    required this.iconName,
  });

  final String id;
  final String name;
  final String category;
  final int durationMinutes;
  final int price;
  final String iconName;
}

class BeautyCenter {
  const BeautyCenter({
    required this.id,
    required this.name,
    required this.city,
    required this.district,
    required this.rating,
    required this.reviews,
    required this.description,
    required this.features,
    required this.specialists,
    required this.services,
  });

  final String id;
  final String name;
  final String city;
  final String district;
  final double rating;
  final int reviews;
  final String description;
  final List<String> features;
  final List<String> specialists;
  final List<BeautyService> services;
}

const _coreBeautyServices = <BeautyService>[
  BeautyService(
    id: 'deep-cleansing',
    name: 'تنظيف عميق للبشرة',
    category: 'العناية بالبشرة',
    durationMinutes: 60,
    price: 12000,
    iconName: 'face',
  ),
  BeautyService(
    id: 'hydrafacial',
    name: 'جلسة هيدرافيشل',
    category: 'العناية بالبشرة',
    durationMinutes: 75,
    price: 18000,
    iconName: 'spa',
  ),
  BeautyService(
    id: 'hair-care',
    name: 'عناية متكاملة بالشعر',
    category: 'الشعر',
    durationMinutes: 90,
    price: 15000,
    iconName: 'hair',
  ),
  BeautyService(
    id: 'massage',
    name: 'مساج واسترخاء',
    category: 'سبا ومساج',
    durationMinutes: 60,
    price: 20000,
    iconName: 'massage',
  ),
  BeautyService(
    id: 'laser',
    name: 'جلسة إزالة الشعر بالليزر',
    category: 'ليزر',
    durationMinutes: 45,
    price: 25000,
    iconName: 'laser',
  ),
  BeautyService(
    id: 'nails',
    name: 'عناية بالأظافر',
    category: 'الأظافر',
    durationMinutes: 50,
    price: 9000,
    iconName: 'nails',
  ),
];

const beautyCenters = <BeautyCenter>[
  BeautyCenter(
    id: 'lavender-sanaa',
    name: 'مركز لافندر للتجميل والعناية',
    city: 'صنعاء',
    district: 'شارع حدة',
    rating: 4.9,
    reviews: 186,
    description:
        'مركز متخصص للعناية بالبشرة والشعر والليزر، يقدم خدماته بأجهزة حديثة وعلى أيدي مختصين معتمدين ضمن بيئة مريحة وآمنة.',
    features: ['مختصون معتمدون', 'أجهزة حديثة', 'غرف خاصة', 'تعقيم مستمر'],
    specialists: ['د. سارة أحمد', 'أ. ريم خالد', 'د. محمود علي'],
    services: _coreBeautyServices,
  ),
  BeautyCenter(
    id: 'rosa-aden',
    name: 'مركز روزا سبا',
    city: 'عدن',
    district: 'خور مكسر',
    rating: 4.8,
    reviews: 142,
    description:
        'سبا عصري للعناية والاسترخاء يقدم جلسات البشرة والمساج والعناية بالشعر بمنتجات موثوقة وخدمة احترافية.',
    features: ['سبا متكامل', 'منتجات أصلية', 'خصوصية تامة', 'مواقف متاحة'],
    specialists: ['أ. هبة سالم', 'أ. منى أحمد', 'أ. نجلاء حسن'],
    services: _coreBeautyServices,
  ),
  BeautyCenter(
    id: 'beauty-touch-ibb',
    name: 'مركز لمسة جمال',
    city: 'إب',
    district: 'الدائري الغربي',
    rating: 4.7,
    reviews: 118,
    description:
        'وجهة متكاملة لخدمات العناية اليومية والمناسبات، مع باقات متنوعة وأسعار مناسبة وحجز سريع للمواعيد.',
    features: ['باقات متنوعة', 'أسعار مناسبة', 'خدمة سريعة', 'تعقيم مستمر'],
    specialists: ['أ. أمل يحيى', 'أ. نور محمد', 'أ. سماح علي'],
    services: _coreBeautyServices,
  ),
  BeautyCenter(
    id: 'aura-hadramout',
    name: 'مركز أورا للتجميل',
    city: 'حضرموت',
    district: 'المكلا',
    rating: 4.8,
    reviews: 96,
    description:
        'مركز راقٍ يقدم حلول العناية بالبشرة والشعر وتقنيات الليزر الحديثة مع استشارات متخصصة قبل كل جلسة.',
    features: ['استشارة مجانية', 'تقنيات حديثة', 'مختصون معتمدون', 'دعم مستمر'],
    specialists: ['د. أروى باوزير', 'أ. إيمان خالد', 'د. أحمد عمر'],
    services: _coreBeautyServices,
  ),
];
